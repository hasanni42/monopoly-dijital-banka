# Telefon üzerinden yayınlama
1. ZIP dosyasını telefonunda aç.
2. GitHub'da yeni bir depo oluştur ve ZIP içindeki dosyaları (package.json, server.js, public klasörü, render.yaml) deponun köküne yükle.
3. Render hesabından New > Web Service seçip GitHub deposunu bağla. Build: `npm install`, Start: `npm start`.
4. Render'ın verdiği HTTPS adresini telefonunda aç. Oda oluştur, kodu veya QR bağlantısını arkadaşlarınla paylaş.
5. Kalıcı kayıt istiyorsan ücretsiz geçici dosya sistemine güvenme: kalıcı disk veya harici veritabanı ekle.

Not: Render planları ve arayüz adımları zamanla değişebilir. Ücretsiz planda uyku/yeniden başlama olabilir. Yayınlama için GitHub ve Render hesabı gerekir.
