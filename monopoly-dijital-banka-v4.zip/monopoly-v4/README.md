# Monopoly Dijital Banka V4 — mobil çok oyunculu prototip

## Kurulum ve yayınlama
Node.js 20+ ortamında `npm install` ve `npm start` komutlarıyla çalışır. Uygulamayı telefonlardan farklı ağlarda kullanmak için Node.js ve WebSocket (Socket.IO) destekleyen HTTPS barındırma hizmetine yayınlayın. Oda koduyla katılma ve QR davet bağlantısı aynı web adresini kullanır.

Render Blueprint için `render.yaml` mevcuttur. Ücretsiz Render servislerinin dosya sistemi geçicidir: `data/rooms.json` kalıcı depolama **garantisi vermez**. Gerçek kalıcılık için kalıcı diskli sunucu veya PostgreSQL gibi harici veritabanı kullanın. Kalıcı disk sunuluyorsa `DATA_DIR=/var/data` gibi diske bağlı bir yol tanımlayın. Tek sunucu örneği kullanın; çoklu sunucuda JSON dosyası senkronize olmaz.

## İşlevler
8 oyuncu, oda kodu, özel başlangıç parası, canlı Socket.IO bakiyeleri, bankaya ödeme, onaylı banka talepleri, tapu, yapı seviyesine göre kira, ev/otel maliyeti, ipotek, tapu devri, iki taraflı ticaret teklifleri, kart ödeme/cezaları, QR davet/ödeme bağlantısı, servet sıralaması, basit istatistikler, uygulama içi bildirimler, yönetici son işlem geri alma, JSON oyun kaydı ve PWA kabuğu.

## Bilinen sınırlar
Bu sürüm üretim için güvenlik denetiminden geçmemiş bir prototiptir. QR bağlantısı bir ödeme yetkisi değildir; yalnızca odaya/alıcıya yönlendirir. Bildirimler uygulama açıkken görünür; arka plan push bildirimi yoktur. Mülk ve kira tarifesi kutu sürümüne göre elle girilir. Kira tahsilatı borçlunun ayrıca onayını istemez. İflas tasfiyesi basitleştirilmiştir. Ticaret mülkleri teklif kabulünde yeniden doğrular, ancak tam Monopoly renk grubu/inşaat/rehin kurallarını uygulamaz. İşlem geri alma en son sunucu işlem anlık görüntüsünü geri alır; geri alma geçmişi sunucuda tutulur. Oyuncu kimliği cihazda saklanan oturum anahtarıyla korunur; üretim için güçlü kimlik doğrulama, hız sınırı, denetim günlüğü ve işlemsel veritabanı gereklidir. Oyuncular oyun sırasında gerçek para göndermez.
